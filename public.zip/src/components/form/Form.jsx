import React, { useState } from 'react'
import Register from './register/Register'
import Login from './login/Login'
import registerImg from ''
import "./Form.css"

export default function Form() {

    const [entered, setEntered] = useState(false)

  return (
    <div className="form">

      <div className="imgBlock"></div>

      <div className="contentBlock">

        <div className="avatar"></div>

        {entered 
            ?   <Login setEntered={setEntered}/>  
            :   <Register setEntered={setEntered}/>
        }
      </div>

        


    </div>
  )
}
