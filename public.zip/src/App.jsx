
import './App.css'
import Form from './components/form/Form'
import Notification from './components/notifications/Notification'

function App() {
  

  return (
    <>
      <Form/>
      <Notification/>
    </>
  )
}

export default App
